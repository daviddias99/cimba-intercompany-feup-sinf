import React, { Fragment} from 'react';

const RouteHandler = () => {

  return (
    <Fragment>
    </Fragment>
  );
};

export default RouteHandler;
