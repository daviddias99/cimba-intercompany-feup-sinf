import React, { Fragment } from 'react';

import Router from 'Router';

const App = () => {
  return (
    <Fragment>
      <Router />
    </Fragment>
  );
};

export default App;
