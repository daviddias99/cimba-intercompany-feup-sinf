const Tab = ({children}) => {
    return (
        children
    );
}

export default Tab;
