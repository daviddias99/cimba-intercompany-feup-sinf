module.exports = {
  additionalProperties: false,
  required: ['username'],
  properties: {
    username: {
      type: 'string',
    },
  },
};
