module.exports = '[0-9]+';
